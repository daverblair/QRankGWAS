from .QRankGWAS import main
main()
